from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from geometry.vector import Vector3
from geometry.color	import Color

@dataclass
class PointLight:
	position: Vector3
	color: Color
	ambient_strength: float = 0.18
	diffuse_strength: float = 0.9
	specular_strength: float = 0.4
	shininess: float = 32.0

	def bind(self, program, view_pos: np.ndarray) -> None:
		if "u_light.position" in program:
			program["u_light.position"].value = tuple(float(v) for v in self.position)
		if "u_light.color" in program:
			program["u_light.color"].value = tuple(float(v) for v in self.color)
		if "u_light.ambient_strength" in program:
			program["u_light.ambient_strength"].value = float(self.ambient_strength)
		if "u_light.diffuse_strength" in program:
			program["u_light.diffuse_strength"].value = float(self.diffuse_strength)
		if "u_light.specular_strength" in program:
			program["u_light.specular_strength"].value = float(self.specular_strength)
		if "u_light.shininess" in program:
			program["u_light.shininess"].value = float(self.shininess)
		if "u_view_pos" in program:
			program["u_view_pos"].value = tuple(float(v) for v in view_pos)
