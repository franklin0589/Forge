
class TestScene(Scene):
	def __init__(self, width: int = 1280, height: int = 720):
		base_dir = Path(__file__).resolve().parent
		shader_dir = base_dir / "shaders"


		position = Vector3(x=0.0, y=0.0, z=3.0)
		target = Vector3(x=0.0, y=0.0, z=0.0)
		up = Vector3(x=0.0, y=1.0, z=0.0)
		cam = Camera(position=position, target=target, up=up)
		
		super().__init__(
			width=width,
			height=height,
			cam = cam,
			vertex_shader_path=str(shader_dir / "lit_texture.vert"),
			fragment_shader_path=str(shader_dir / "lit_texture.frag"),
		)
	
	def update(self) -> None:
		self.scene_time += 1

		# Rough rig animation: oscillate child bone around Z.
		bend = 32.0 * np.sin(self.scene_time * 0.08)
		self.mesh_skeleton.set_local_pose(self.child_bone_index, self.child_bind @ rotation_z_matrix(bend))
		self.mesh_skeleton.update_pose()
		if hasattr(self, "skeleton_debug"):
			self.skeleton_debug.update_from_skeleton()
			self.skeleton_debug.build()  # Rebuild the skeleton debug model with updated bone positions

	def build_scene(self) -> None:

		t = Transform()
		t.translate(0.0, 1, -3.0)
		self.mesh_transform = t

		import_mesh = ImportedMesh(mesh_path="C:\\Users\\Franklin\\Documents\\Programming\\Fain\\Art\\Models\\low_poly\\scene.gltf", color=(0.3, 0.85, 0.95))
		self.mesh = RenderableObject(
			mesh=import_mesh,
			transform=t,
			material=Material(
				use_texture=False,
				use_lighting=True,
				uniforms={
					"u_light.shininess": 94.0,
				},
			),
		)
		# Rough rig setup: root -> child, with child offset in bind pose.
		self.mesh_skeleton = Skeleton()
		root = self.mesh_skeleton.create_bone("root", parent=-1, local_bind=None, local_pose=None)
		self.child_bind =Transform(np.array(
			[
				[1.0, 0.0, 0.0, 0.0],
				[0.0, 1.0, 0.0, 0.75],
				[0.0, 0.0, 1.0, 0.0],
				[0.0, 0.0, 0.0, 1.0],
			],
			dtype=np.float32,
		))
		self.child_bone_index = self.mesh_skeleton.create_bone("child", parent=root, local_bind=self.child_bind, local_pose=None)
		import_mesh.attach_skeleton(self.mesh_skeleton, self.mesh.model, root=0, high_bone=self.child_bone_index)
		# Step 3: use imported glTF joints/weights when available, fallback to axis gradient.
		self.add(self.mesh)
	
		# Render animated skeleton bones as line segments on top of the model.
		self.skeleton_debug = SkeletonDebugObject(
			skeleton=self.mesh_skeleton,
			transform=t,
			color=(1.0, 0.95, 0.2),
		)
		self.add(self.skeleton_debug)

		# Joint markers make the animated skeleton readable in final renders.
	
		


		self.add_light(
			PointLight(
				position=np.array([3.5, 4.0, 3.0], dtype=np.float32),
				color=np.array([1.0, 1.0, 1.0], dtype=np.float32),
				ambient_strength=0.20,
				diffuse_strength=0.95,
				specular_strength=0.45,
				shininess=32.0,
			)
		)
		


if __name__ == "__main__":
	TestScene(width=1280, height=720).render_gif()