try:
    from .script_block import ScriptBlock
except ImportError:
    from script_block import ScriptBlock


class CommonVertexShader:
    def __init__(self, has_normal: bool, has_uv: bool, use_skin: bool) -> None:

        self.header = ScriptBlock(["#version 330"])
        self.inputs = ScriptBlock([
            "in vec3 in_pos;",
            "in vec3 in_color;",
        ])
        self.outputs = ScriptBlock([
            "out vec3 v_color;",
            "out vec3 v_frag_pos;",
        ])
        self.uniforms = ScriptBlock([
            "uniform mat4 u_mvp;",
            "uniform mat4 u_model;",
        ])
        self.body = ScriptBlock()
        if has_normal:
            self.inputs.add("in vec3 in_normal;")
            self.outputs.add("out vec3 v_normal;")
        if has_uv:
            self.inputs.add("in vec2 in_uv;")
            self.outputs.add("out vec2 v_uv;")
        
        if use_skin:
            self.inputs.extend([
                "in vec4 in_bone_ids;",
                "in vec4 in_bone_weights;",
            ])
            self.uniforms.add("uniform mat4 u_bones[64];")

        if use_skin:
            self.body.extend([
                "vec4 skin_pos = vec4(0.0);",
                "vec3 skin_normal = vec3(0.0);" if has_normal else "",
                "for (int i = 0; i < 4; ++i) {",
                "    int bone_index = int(in_bone_ids[i]);",
                "    float weight = in_bone_weights[i];",
                "    skin_pos += (u_bones[bone_index] * vec4(in_pos, 1.0)) * weight;",
                "}",
            ])
            if has_normal:
                self.body.extend([
                    "for (int i = 0; i < 4; ++i) {",
                    "    int bone_index = int(in_bone_ids[i]);",
                    "    float weight = in_bone_weights[i];",
                    "    skin_normal += (mat3(u_bones[bone_index]) * in_normal) * weight;",
                    "}",
                    "vec3 local_normal = normalize(skin_normal);",
                ])
            self.body.add("vec3 local_pos = skin_pos.xyz;")
        else:
            self.body.add("vec3 local_pos = in_pos;")
            if has_normal:
                self.body.add("vec3 local_normal = in_normal;")

        self.body.add("v_color = in_color;")
        self.body.add("v_frag_pos = vec3(u_model * vec4(local_pos, 1.0));")
        if has_normal:
            self.body.add("v_normal = mat3(transpose(inverse(u_model))) * local_normal;")
        if has_uv:
            self.body.add("v_uv = in_uv;")
        self.body.add("gl_Position = u_mvp * vec4(local_pos, 1.0);")


    def build(self) -> str:
        shader_source = ScriptBlock()
        shader_source.extend(self.header.lines)
        shader_source.extend(self.inputs.lines)
        shader_source.extend(self.outputs.lines)
        shader_source.extend(self.uniforms.lines)
        shader_source.add("void main() {")
        shader_source.extend(self.body.lines)
        shader_source.add("}")
        return shader_source.render()
    
if __name__ == "__main__":
    print(CommonVertexShader(has_normal=True, has_uv=True, use_skin=True).build())