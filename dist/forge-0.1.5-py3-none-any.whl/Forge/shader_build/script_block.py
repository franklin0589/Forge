

from dataclasses import dataclass, field


@dataclass
class ScriptBlock:
	"""Small reusable block of GLSL source lines.

	The builder composes full shader scripts from blocks instead of
	concatenating large strings in one place.
	"""

	lines: list[str] = field(default_factory=list)

	def add(self, line: str) -> None:
		if line:
			self.lines.append(line)

	def extend(self, lines: list[str], indent:int=0) -> None:
		for line in lines:
			self.add("\t" * indent + line)

	def render(self) -> str:
		return "\n".join(self.lines)
