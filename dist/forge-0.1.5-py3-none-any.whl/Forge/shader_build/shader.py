import moderngl
from object.texture import Texture2D

class VertexShader:
    def __init__(self, source: str) -> None:
        self.source_path = source
    
    def load(self):
        with open(self.source_path, 'r') as f:
            return f.read()

class FragmentShader:
    def __init__(self, source: str) -> None:
        self.source_path = source
    
    def load(self):
        with open(self.source_path, 'r') as f:
            return f.read()


class ShaderWrapper:
    def __init__(
        self,
        ctx: moderngl.Context,
        vertex_path: str | None = None,
        fragment_path: str | None = None,
        vertex_source: str | None = None,
        fragment_source: str | None = None,
    ) -> None:
        self.ctx = ctx
        self.vertex_path = vertex_path
        self.fragment_path = fragment_path
        if vertex_source is None:
            if vertex_path is None:
                raise ValueError("vertex_path or vertex_source is required")
            self.vertex_shader = VertexShader(vertex_path)
            vertex_source = self.vertex_shader.load()
        if fragment_source is None:
            if fragment_path is None:
                raise ValueError("fragment_path or fragment_source is required")
            self.fragment_shader = FragmentShader(fragment_path)
            fragment_source = self.fragment_shader.load()

        self.program = self.ctx.program(vertex_shader=vertex_source, fragment_shader=fragment_source)
        self.vbo = None
        self.ibo = None
        self.vao = None
        self.tex = None

    def run(self, input_key, input_buffer: str):
        data = input_buffer.matrix.astype("f4")
        if data.ndim == 2 and data.shape == (4, 4):
            data = data.T
        self.program[input_key].write(data.tobytes())

    def set_vec3(self, input_key: str, value) -> None:
        if input_key in self.program:
            self.program[input_key].value = tuple(float(v) for v in value)

    def set_float(self, input_key: str, value: float) -> None:
        if input_key in self.program:
            self.program[input_key].value = float(value)

    def render(self, model, vertex_format: str = "3f 3f", attributes: list[str] = ["in_pos", "in_color"]):
        self.vbo = self.ctx.buffer(model.vertices.tobytes())
        self.ibo = None

        if model.indices is not None:
            index_data = model.indices
            if index_data.dtype != "u4":
                index_data = index_data.astype("u4")
            self.ibo = self.ctx.buffer(index_data.tobytes())

        self.vao = self.ctx.vertex_array(
            self.program,
            [(self.vbo, vertex_format, *attributes)],
            index_buffer=self.ibo,
        )

        if model.texture_path is not None and "u_tex" in self.program:
            self.tex = Texture2D(self.ctx, model.texture_path)
            self.tex.use(unit=model.texture_unit)
            self.program["u_tex"].value = model.texture_unit

        if getattr(model, "material", None) is not None:
            for key, value in model.material.uniforms.items():
                if key not in self.program:
                    continue
                if isinstance(value, tuple) and len(value) == 3:
                    self.program[key].value = tuple(float(v) for v in value)
                else:
                    self.program[key].value = float(value)

        if "u_uv_weight" in self.program and (
            getattr(model, "material", None) is None
            or "u_uv_weight" not in model.material.uniforms
        ):
            self.program["u_uv_weight"].value = 0.0

        mode_name = str(getattr(model, "render_mode", "triangles")).lower()
        mode = moderngl.LINES if mode_name == "lines" else moderngl.TRIANGLES
        self.vao.render(mode)
