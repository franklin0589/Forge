from .script_block import ScriptBlock


class CommonFragmentShader:
    def __init__(self, has_normal: bool, has_uv: bool, use_texture: bool, use_lighting: bool) -> None:
        self.header = ScriptBlock(["#version 330"])
        self.inputs = ScriptBlock([
            "in vec3 v_color;",
            "in vec3 v_frag_pos;",
        ])
        self.outputs = ScriptBlock(["out vec4 fragColor;"])
        self.uniforms = ScriptBlock()
        self.body = ScriptBlock()

        if has_normal:
            self.inputs.add("in vec3 v_normal;")
        if has_uv:
            self.inputs.add("in vec2 v_uv;")
        
        if use_texture and has_uv:
            self.uniforms.add("uniform sampler2D u_tex;")
        if has_uv and not use_texture:
            self.uniforms.add("uniform float u_uv_weight;")
        if use_lighting and has_normal:
            self.uniforms.extend([
                "struct PointLight {",
                "    vec3 position;",
                "    vec3 color;",
                "    float ambient_strength;",
                "    float diffuse_strength;",
                "    float specular_strength;",
                "    float shininess;",
                "};",
                "uniform PointLight u_light;",
                "uniform vec3 u_view_pos;",
            ])
        if use_lighting and has_normal:
            self.body.extend([
                "vec3 normal = normalize(v_normal);",
                "vec3 light_dir = normalize(u_light.position - v_frag_pos);",
                "vec3 view_dir = normalize(u_view_pos - v_frag_pos);",
                "vec3 half_dir = normalize(light_dir + view_dir);",
                "float diff = max(dot(normal, light_dir), 0.0);",
                "float spec = pow(max(dot(normal, half_dir), 0.0), u_light.shininess);",
                "vec3 ambient = u_light.ambient_strength * u_light.color;",
                "vec3 diffuse = u_light.diffuse_strength * diff * u_light.color;",
                "vec3 specular = u_light.specular_strength * spec * u_light.color;",
                "vec3 lit = ambient + diffuse + specular;",
            ])
        else:
            self.body.add("vec3 lit = vec3(1.0);")

        if use_texture and has_uv:
            self.body.add("vec3 albedo = texture(u_tex, v_uv).rgb * v_color;")
        elif has_uv:
            self.body.extend([
                "vec3 albedo = v_color;",
                "albedo += vec3(v_uv, 0.0) * u_uv_weight;",
            ])
        else:
            self.body.add("vec3 albedo = v_color;")

        self.body.add("fragColor = vec4(albedo * lit, 1.0);")

    def build(self) -> str:
        shader_source = ScriptBlock()
        shader_source.extend(self.header.lines)
        shader_source.extend(self.inputs.lines)
        shader_source.extend(self.uniforms.lines)
        shader_source.extend(self.outputs.lines)
        shader_source.extend(ScriptBlock(["void main() {"]).lines)
        shader_source.extend(self.body.lines)
        shader_source.extend(ScriptBlock(["}"]).lines)
        return shader_source.render()