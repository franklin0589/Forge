import numpy as np
from geometry.perspective import look_at, perspective
from geometry.transform import Transform
from geometry.vector import Vector3


class Camera:
    def __init__(
        self,
        position: Vector3,
        target: Vector3,
        up: Vector3,
        fov_y_deg: float = 60.0,
        near: float = 0.1,
        far: float = 100.0,
    ) -> None:
        self.position = position
        self.target = target
        self.up = up
        self.fov_y_deg = fov_y_deg
        self.near = near
        self.far = far

    def view_matrix(self) -> Transform:
        return look_at(self.position, self.target, self.up)

    def projection_matrix(self, width: int, height: int) -> Transform:
        aspect = width / height
        return perspective(self.fov_y_deg, aspect, self.near, self.far)

    def view_projection_matrix(self, width: int, height: int) -> Transform:
        return self.projection_matrix(width, height) @ self.view_matrix()

    def get_mvp(self, model: Transform, width: int, height: int) -> Transform:
        return self.view_projection_matrix(width, height) @ model

    def set_position(self, position: Vector3) -> None:
        self.position = position

    def set_target(self, target: Vector3) -> None:
        self.target = target

    def zoom(self, amount: float) -> None:
        direction = (self.target - self.position).normalized()
        self.position += direction * amount

    def rotate(self, axis: Vector3, angle_deg: float) -> None:
        direction = (self.target - self.position).normalized()
        rotation_matrix = Transform.rotation(axis, angle_deg)
        rotated_direction = rotation_matrix.transform_vector(direction)
        self.target = self.position + rotated_direction

    def move(self, direction: Vector3, amount: float) -> None:
        direction = direction.normalized()
        self.position += direction * amount
        self.target += direction * amount
