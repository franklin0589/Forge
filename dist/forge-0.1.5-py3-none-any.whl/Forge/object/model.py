from __future__ import annotations

import numpy as np
from object.materials import Material
from object.rig import Skeleton
from dataclasses import dataclass

# Model is the final render payload consumed by Context/ShaderWrapper.
# It carries geometry buffers plus shader/material/rigging metadata.
from geometry.transform import Transform


# @dataclass
# class Model:


class Model:
    def __init__(
        self,
        vertices: np.ndarray,
        point: Transform,
        indices: np.ndarray | None = None,
        texture_path: str | None = None,
        texture_unit: int = 0,
        vertex_format: str = "3f 3f",
        attributes: list[str] | None = None,
        vertex_shader_path: str | None = None,
        fragment_shader_path: str | None = None,
        vertex_shader_source: str | None = None,
        fragment_shader_source: str | None = None,
        material: Material | None = None,
        skeleton: Skeleton | None = None,
        max_bones: int = 64,
        render_mode: str = "triangles",
        depth_test: bool = True,
    ) -> None:
        self.vertices = vertices
        self.point = point
        self.indices = indices
        self.texture_path = texture_path
        self.texture_unit = texture_unit
        self.vertex_format = vertex_format
        self.attributes = attributes if attributes is not None else ["in_pos", "in_color"]
        self.vertex_shader_path = vertex_shader_path
        self.fragment_shader_path = fragment_shader_path
        self.vertex_shader_source = vertex_shader_source
        self.fragment_shader_source = fragment_shader_source
        self.material = material
        self.skeleton = skeleton
        self.max_bones = max_bones
        self.render_mode = render_mode
        self.depth_test = depth_test

    def has_skinning(self) -> bool:
        return self.skeleton is not None

    def uses_texture(self) -> bool:
        return bool(self.material is not None and self.material.use_texture)

    def render_profile(self) -> str:
        if str(self.render_mode).lower() == "lines":
            return "overlay"
        if self.has_skinning():
            return "skinned_textured" if self.uses_texture() else "skinned"
        if self.uses_texture():
            return "textured"
        return "plain"

    def resolve_render_strategy(self):
        from object.render_strategy import resolve_render_strategy

        return resolve_render_strategy(self)