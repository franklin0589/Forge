from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

import moderngl
import numpy as np

if TYPE_CHECKING:
	from object.model import Model
	from object.materials import ShaderScript


@dataclass(frozen=True)
class RenderStrategy:
	"""Small execution plan for one model type.

	The strategy decides which shader source to use, whether bones need to be
	uploaded, and how the final draw call should be issued.
	"""

	name: str
	render_mode: int = moderngl.TRIANGLES
	depth_test: bool = True
	upload_skeleton: bool = False

	def shader_script(self, model: "Model") -> "ShaderScript | None":
		if model.vertex_shader_path or model.fragment_shader_path:
			return None
		if model.material is None:
			return None
		return model.material.build_shader_script(model.attributes)

	def upload(self, program, model: "Model", lights=None, view_pos=None) -> None:
		if lights:
			lights[0].bind(program, view_pos)

		if self.upload_skeleton and getattr(model, "skeleton", None) is not None:
			model.skeleton.update_pose()
			bones = model.skeleton.skinning_buffer()
			if bones.size > 0 and "u_bones" in program:
				max_bones = int(getattr(model, "max_bones", 64))
				count = min(bones.shape[0], max_bones)
				payload = _pack_bones(bones, max_bones, count)
				program["u_bones"].write(payload)


class PlainRenderStrategy(RenderStrategy):
	def __init__(self) -> None:
		super().__init__(name="plain")


class TexturedRenderStrategy(RenderStrategy):
	def __init__(self) -> None:
		super().__init__(name="textured")


class SkinnedRenderStrategy(RenderStrategy):
	def __init__(self) -> None:
		super().__init__(name="skinned", upload_skeleton=True)


class SkinnedTexturedRenderStrategy(RenderStrategy):
	def __init__(self) -> None:
		super().__init__(name="skinned_textured", upload_skeleton=True)


class OverlayRenderStrategy(RenderStrategy):
	def __init__(self) -> None:
		super().__init__(name="overlay", render_mode=moderngl.LINES, depth_test=False)


def _pack_bones(bones, max_bones: int, count: int) -> bytes:
	padded = np.stack([np.eye(4, dtype=np.float32) for _ in range(max_bones)])
	padded[:count] = bones[:count]
	return padded.transpose(0, 2, 1).astype("f4").tobytes()


def resolve_render_strategy(model: "Model") -> RenderStrategy:
	profile = model.render_profile()
	if profile == "overlay":
		return OverlayRenderStrategy()
	if profile == "skinned_textured":
		return SkinnedTexturedRenderStrategy()
	if profile == "skinned":
		return SkinnedRenderStrategy()
	if profile == "textured":
		return TexturedRenderStrategy()
	return PlainRenderStrategy()
