from __future__ import annotations

from pathlib import Path

import moderngl
from PIL import Image


class Texture2D:
	# Thin wrapper around moderngl.Texture creation and binding.
	def __init__(self, ctx: moderngl.Context, image_path: str, flip_y: bool = True) -> None:
		self.ctx = ctx
		self.image_path = image_path
		self.flip_y = flip_y
		self.texture: moderngl.Texture | None = None

	def load(self) -> moderngl.Texture:
		# Read once from disk and upload as RGBA texture with mipmaps.
		img = Image.open(Path(self.image_path)).convert("RGBA")
		if self.flip_y:
			img = img.transpose(Image.FLIP_TOP_BOTTOM)

		tex = self.ctx.texture(img.size, 4, img.tobytes())
		tex.filter = (moderngl.LINEAR_MIPMAP_LINEAR, moderngl.LINEAR)
		tex.repeat_x = True
		tex.repeat_y = True
		tex.build_mipmaps()
		self.texture = tex
		return tex

	def use(self, unit: int = 0) -> None:
		# Lazy-load the texture the first time it is bound.
		if self.texture is None:
			self.load()
		assert self.texture is not None
		self.texture.use(location=unit)
