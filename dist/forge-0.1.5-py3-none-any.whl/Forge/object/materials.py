from __future__ import annotations

from dataclasses import dataclass, field
from shader_build.frag_shader import CommonFragmentShader
from shader_build.vertex_shader import CommonVertexShader



@dataclass
class ShaderScript:
	# Pair of generated shader sources for one material configuration.
	vertex_source: str
	fragment_source: str


class ShaderScriptBuilder:
	"""Build GLSL from feature-based ScriptBlocks.

	Each section is assembled from small blocks so the active features are
	easy to reason about and easy to extend.
	"""

	@staticmethod
	def build(has_normal: bool, has_uv: bool, use_texture: bool, use_lighting: bool) -> ShaderScript:
		return ShaderScriptBuilder.build_with_skin(
			has_normal=has_normal,
			has_uv=has_uv,
			use_texture=use_texture,
			use_lighting=use_lighting,
			has_skin=False,
		)

	@staticmethod
	def build_with_skin(
		has_normal: bool,
		has_uv: bool,
		use_texture: bool,
		use_lighting: bool,
		has_skin: bool,
	) -> ShaderScript:
		# Vertex blocks.

		vertex_source = CommonVertexShader(has_normal, has_uv, has_skin).build()
		fragment_source = CommonFragmentShader(has_normal, has_uv, use_texture, use_lighting).build()
		
		return ShaderScript(vertex_source=vertex_source, fragment_source=fragment_source)



@dataclass
class Material:
	# Optional fixed shader paths override dynamic shader generation.
	texture_path: str | None = None
	vertex_shader_path: str | None = None
	fragment_shader_path: str | None = None
	use_texture: bool = False
	use_lighting: bool = False
	uniforms: dict[str, float | tuple[float, float, float]] = field(default_factory=dict)

	def build_shader_script(self, attributes: list[str]) -> ShaderScript | None:
		# Use file-based shaders when explicitly provided.
		if self.vertex_shader_path or self.fragment_shader_path:
			return None
		has_normal = "in_normal" in attributes
		has_uv = "in_uv" in attributes
		has_skin = "in_bone_ids" in attributes and "in_bone_weights" in attributes
		return ShaderScriptBuilder.build_with_skin(
			has_normal=has_normal,
			has_uv=has_uv,
			use_texture=self.use_texture,
			use_lighting=self.use_lighting,
			has_skin=has_skin,
		)
