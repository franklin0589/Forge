from __future__ import annotations

from pathlib import Path

import numpy as np
from abc import ABC, abstractmethod
from object.skinning import SkinWeights, Skinning

# Mesh module responsibilities:
# 1) generate procedural primitive buffers
# 2) load external mesh data into the renderer's interleaved layout
# 3) optionally extract skinning weights from imported assets


class Mesh(ABC):
    def __init__(self, vertices: np.ndarray, indices: np.ndarray | None = None) -> None:
        self.vertices = vertices
        self.indices = indices

    def get_vertices(self) -> np.ndarray:
        return self.vertices

    def get_indices(self) -> np.ndarray | None:
        return self.indices

    @abstractmethod
    def build(self) -> tuple[np.ndarray, np.ndarray | None]:
        # Returns a flat vertex buffer and optional index buffer.
        return self.vertices, self.indices

    def rebuild(self) -> tuple[np.ndarray, np.ndarray | None]:
        vertices, indices = self.build()
        self.vertices = vertices
        self.indices = indices
        return self.vertices, self.indices

class CubeMesh(Mesh):
    def __init__(
        self,
        size: float = 1.0,
        color: tuple[float, float, float] | None = None,
        per_face_colors: bool = False,
    ) -> None:
        self.size = size
        self.color = color
        self.per_face_colors = per_face_colors
        vertices, indices = self.build()
        super().__init__(vertices=vertices, indices=indices)

    def build(self) -> tuple[np.ndarray, np.ndarray]:
        h = self.size / 2.0
        if self.per_face_colors:
            face_specs = [
                ([(-h, -h, h), (h, -h, h), (h, h, h), (-h, h, h)], (0.96, 0.55, 0.25)),
                ([(-h, -h, -h), (h, -h, -h), (h, h, -h), (-h, h, -h)], (0.75, 0.35, 0.18)),
                ([(-h, -h, -h), (-h, -h, h), (-h, h, h), (-h, h, -h)], (0.95, 0.72, 0.34)),
                ([(h, -h, -h), (h, -h, h), (h, h, h), (h, h, -h)], (0.80, 0.45, 0.20)),
                ([(-h, h, -h), (-h, h, h), (h, h, h), (h, h, -h)], (1.00, 0.82, 0.42)),
                ([(-h, -h, -h), (-h, -h, h), (h, -h, h), (h, -h, -h)], (0.62, 0.31, 0.14)),
            ]
            if self.color is not None:
                face_specs = [(quad, self.color) for quad, _ in face_specs]

            packed_vertices: list[float] = []
            packed_indices: list[int] = []
            for face_idx, (quad, face_color) in enumerate(face_specs):
                base = face_idx * 4
                for vx, vy, vz in quad:
                    packed_vertices.extend([vx, vy, vz, face_color[0], face_color[1], face_color[2]])
                packed_indices.extend([base, base + 1, base + 2, base, base + 2, base + 3])

            return np.array(packed_vertices, dtype=np.float32), np.array(packed_indices, dtype=np.uint32)

        # Indexed cube with shared vertices (8 unique positions).
        base_vertices = np.array(
            [
                [-h, -h, -h],
                [h, -h, -h],
                [h, h, -h],
                [-h, h, -h],
                [-h, -h, h],
                [h, -h, h],
                [h, h, h],
                [-h, h, h],
            ],
            dtype=np.float32,
        )

        cube_indices = np.array(
            [
                4, 5, 6, 4, 6, 7,  # +Z
                0, 1, 2, 0, 2, 3,  # -Z
                0, 4, 7, 0, 7, 3,  # -X
                1, 5, 6, 1, 6, 2,  # +X
                3, 2, 6, 3, 6, 7,  # +Y
                0, 1, 5, 0, 5, 4,  # -Y
            ],
            dtype=np.uint32,
        )

        base_color = self.color if self.color is not None else (0.95, 0.55, 0.25)
        color_array = np.tile(np.array(base_color, dtype=np.float32), (base_vertices.shape[0], 1))
        vertices = np.hstack((base_vertices, color_array)).reshape(-1).astype(np.float32)
        return vertices, cube_indices


class TexturedCubeMesh(Mesh):
    def __init__(self, size: float = 1.0, color: tuple[float, float, float] = (1.0, 1.0, 1.0)) -> None:
        self.size = size
        self.color = color
        vertices, indices = self.build()
        super().__init__(vertices=vertices, indices=indices)

    def build(self) -> tuple[np.ndarray, np.ndarray]:
        h = self.size / 2.0

        # 24 vertices (4 per face) to support face UVs and flat normals.
        face_data = [
            ([(-h, -h, h), (h, -h, h), (h, h, h), (-h, h, h)], (0.0, 0.0, 1.0)),       # +Z
            ([(h, -h, -h), (-h, -h, -h), (-h, h, -h), (h, h, -h)], (0.0, 0.0, -1.0)),   # -Z
            ([(-h, -h, -h), (-h, -h, h), (-h, h, h), (-h, h, -h)], (-1.0, 0.0, 0.0)),   # -X
            ([(h, -h, h), (h, -h, -h), (h, h, -h), (h, h, h)], (1.0, 0.0, 0.0)),         # +X
            ([(-h, h, h), (h, h, h), (h, h, -h), (-h, h, -h)], (0.0, 1.0, 0.0)),         # +Y
            ([(-h, -h, -h), (h, -h, -h), (h, -h, h), (-h, -h, h)], (0.0, -1.0, 0.0)),    # -Y
        ]
        uv_quad = [(0.0, 0.0), (1.0, 0.0), (1.0, 1.0), (0.0, 1.0)]

        packed_vertices: list[float] = []
        packed_indices: list[int] = []

        for face_idx, (quad, normal) in enumerate(face_data):
            base = face_idx * 4
            for (vx, vy, vz), (u, v) in zip(quad, uv_quad):
                packed_vertices.extend([
                    vx,
                    vy,
                    vz,
                    self.color[0],
                    self.color[1],
                    self.color[2],
                    normal[0],
                    normal[1],
                    normal[2],
                    u,
                    v,
                ])
            packed_indices.extend([base, base + 1, base + 2, base, base + 2, base + 3])

        return np.array(packed_vertices, dtype=np.float32), np.array(packed_indices, dtype=np.uint32)


class TexturedPlaneMesh(Mesh):
    def __init__(
        self,
        width: float = 2.0,
        depth: float = 2.0,
        color: tuple[float, float, float] = (1.0, 1.0, 1.0),
        uv_scale: tuple[float, float] = (1.0, 1.0),
    ) -> None:
        self.width = width
        self.depth = depth
        self.color = color
        self.uv_scale = uv_scale
        vertices, indices = self.build()
        super().__init__(vertices=vertices, indices=indices)

    def build(self) -> tuple[np.ndarray, np.ndarray]:
        hw = self.width * 0.5
        hd = self.depth * 0.5
        su, sv = self.uv_scale

        # Plane on XZ with +Y normal.
        # Layout per vertex: pos(3), color(3), normal(3), uv(2)
        vertices = np.array(
            [
                -hw, 0.0, -hd, self.color[0], self.color[1], self.color[2], 0.0, 1.0, 0.0, 0.0, 0.0,
                hw, 0.0, -hd, self.color[0], self.color[1], self.color[2], 0.0, 1.0, 0.0, su, 0.0,
                hw, 0.0, hd, self.color[0], self.color[1], self.color[2], 0.0, 1.0, 0.0, su, sv,
                -hw, 0.0, hd, self.color[0], self.color[1], self.color[2], 0.0, 1.0, 0.0, 0.0, sv,
            ],
            dtype=np.float32,
        )
        indices = np.array([0, 1, 2, 0, 2, 3], dtype=np.uint32)
        return vertices, indices



class BoneMesh(Mesh):
    def __init__(self, skeleton) -> None:
        self.skeleton = skeleton
        self.bones = skeleton.bones
        self.pose_world_matrices = skeleton.pose_world_matrices
        vertices, indices = self.build()
        super().__init__(vertices=vertices, indices=indices)

    def build(self) -> tuple[np.ndarray, np.ndarray]:
        color = (0.85, 0.85, 0.85)  # Default color for the bones
        line_points: list[tuple[np.ndarray, np.ndarray]] = []
        for i, bone in enumerate(self.bones):
            if bone.parent < 0:
                continue
            parent_pos = self.pose_world_matrices[bone.parent].matrix[:3, 3].astype(np.float32)
            child_pos = self.pose_world_matrices[i].matrix[:3, 3].astype(np.float32)
            line_points.append((parent_pos, child_pos))

        if not line_points:
            # Fallback: draw a tiny axis marker at the root when no edges exist.
            root_pos = (
                self.pose_world_matrices[0].matrix[:3, 3].astype(np.float32)
                if self.pose_world_matrices
                else np.zeros(3, dtype=np.float32)
            )
            line_points = [
                (root_pos, root_pos + np.array([0.0, 0.12, 0.0], dtype=np.float32)),
            ]

        vertices: list[float] = []
        indices: list[int] = []
        idx = 0
        for a, b in line_points:
            vertices.extend([a[0], a[1], a[2], color[0], color[1], color[2]])
            vertices.extend([b[0], b[1], b[2], color[0], color[1], color[2]])
            indices.extend([idx, idx + 1])
            idx += 2

        return np.array(vertices, dtype=np.float32), np.array(indices, dtype=np.uint32)

class SphereMesh(Mesh):
    def __init__(self, radius: float = 1.0, segments: int = 16, rings: int = 16) -> None:
        self.radius = radius
        self.segments = segments
        self.rings = rings
        vertices, indices = self.build()
        super().__init__(vertices=vertices, indices=indices)

    def calculate_normal(self, vertex: np.ndarray) -> np.ndarray:
        norm = np.linalg.norm(vertex)
        if norm == 0:
            return np.array([0.0, 0.0, 0.0], dtype=np.float32)
        return vertex / norm

    def build(self) -> tuple[np.ndarray, np.ndarray]:
        vertices: list[float] = []
        indices: list[int] = []
        color = (0.85, 0.85, 0.85)  # Default color for the sphere
        for ring in range(self.rings + 1):
            theta = np.pi * ring / self.rings
            sin_theta = np.sin(theta)
            cos_theta = np.cos(theta)

            for segment in range(self.segments + 1):
                phi = 2 * np.pi * segment / self.segments
                sin_phi = np.sin(phi)
                cos_phi = np.cos(phi)

                x = self.radius * sin_theta * cos_phi
                y = self.radius * cos_theta
                z = self.radius * sin_theta * sin_phi
                normal = self.calculate_normal(np.array([x, y, z], dtype=np.float32))
                vertices.extend([x, y, z, color[0], color[1], color[2], normal[0], normal[1], normal[2]])

        for ring in range(self.rings):
            for segment in range(self.segments):
                first = (ring * (self.segments + 1)) + segment
                second = first + self.segments + 1

                indices.extend([first, second, first + 1])
                indices.extend([second, second + 1, first + 1])

        return np.array(vertices, dtype=np.float32), np.array(indices, dtype=np.uint32)


class ImportedMesh(Mesh):
    def __init__(self, mesh_path: str | Path, color: tuple[float, float, float] = (0.4, 0.85, 0.95)) -> None:
        self.mesh_path = Path(mesh_path)
        self.color = color
        self.skin_weights: SkinWeights | None = None
        vertices, indices = self.build()

        super().__init__(vertices=vertices, indices=indices)

    def attach_skeleton(self, skeleton, model, root: int = 0, high_bone: int = 0) -> None:
        imported_skin = self.skin_weights
        if imported_skin is not None:
            ids = imported_skin.bone_ids.astype(np.int32)
            w = imported_skin.bone_weights.astype(np.float32)
            bone_count = len(self.mesh_skeleton.bones)
            valid = (ids >= 0) & (ids < bone_count)
            valid_weight = np.any((w > 1e-4) & valid)
            child_weight = np.any((ids == self.child_bone_index) & (w > 0.05) & valid)
            # Imported weights often target a different rig. If they don't drive our child bone,
            # switch to a procedural gradient so deformation is visible in this rough demo.
            if (not valid_weight) or (not child_weight):
                imported_skin = None
        if imported_skin is None:
            imported_skin = Skinning.axis_gradient_weights(
                model,
                low_bone=root,
                high_bone=high_bone,
                axis=1,
            )
        Skinning(model, skeleton=skeleton).attach(imported_skin)

    def build(self) -> tuple[np.ndarray, np.ndarray | None]:
        # Keep imported skin weights for later rig attachment.
        vertices, indices, skin_weights = load_mesh_vertices(self.mesh_path, color=self.color)
        self.skin_weights = skin_weights
        return vertices, indices


def _extract_skin_weights(mesh, vertex_count: int) -> SkinWeights | None:
    # Rough extractor for glTF-like JOINTS_0 / WEIGHTS_0 vertex attributes.
    attrs = getattr(mesh, "vertex_attributes", None)
    if not isinstance(attrs, dict):
        return None

    joints = attrs.get("JOINTS_0") or attrs.get("joints")
    weights = attrs.get("WEIGHTS_0") or attrs.get("weights")
    if joints is None or weights is None:
        return None

    j = np.asarray(joints)
    w = np.asarray(weights, dtype=np.float32)
    if j.ndim != 2 or w.ndim != 2:
        return None
    if j.shape[1] < 1 or w.shape[1] < 1:
        return None

    if j.shape[1] < 4:
        j_pad = np.zeros((j.shape[0], 4), dtype=np.int32)
        j_pad[:, : j.shape[1]] = j.astype(np.int32)
        j = j_pad
    else:
        j = j[:, :4].astype(np.int32)

    if w.shape[1] < 4:
        w_pad = np.zeros((w.shape[0], 4), dtype=np.float32)
        w_pad[:, : w.shape[1]] = w.astype(np.float32)
        w = w_pad
    else:
        w = w[:, :4].astype(np.float32)

    if j.shape[0] != vertex_count or w.shape[0] != vertex_count:
        count = min(vertex_count, j.shape[0], w.shape[0])
        j_fix = np.zeros((vertex_count, 4), dtype=np.int32)
        w_fix = np.zeros((vertex_count, 4), dtype=np.float32)
        j_fix[:count] = j[:count]
        w_fix[:count] = w[:count]
        j, w = j_fix, w_fix

    return SkinWeights(bone_ids=j, bone_weights=w)

def load_mesh_vertices(
    mesh_path: str | Path,
    color: tuple[float, float, float] = (0.4, 0.85, 0.95),
) -> tuple[np.ndarray, np.ndarray, SkinWeights | None]:
    """
    Load a mesh file and return interleaved vertices: [x, y, z, r, g, b] per vertex.

    Supported by default: STL, OBJ, PLY, GLTF/GLB (via trimesh loaders).
    FBX and BLEND can work if trimesh has a backend available (assimp/blender).
    """
    try:
        import trimesh
    except ImportError as exc:
        raise RuntimeError("Mesh import requires trimesh. Install with: pip install trimesh") from exc

    mesh_path = Path(mesh_path)
    if not mesh_path.exists():
        raise FileNotFoundError(f"Mesh file not found: {mesh_path}")

    loaded = trimesh.load(mesh_path, force="mesh")

    if isinstance(loaded, trimesh.Scene):
        geometries = [g for g in loaded.geometry.values() if isinstance(g, trimesh.Trimesh)]
        if not geometries:
            raise ValueError(f"No mesh geometry found in file: {mesh_path}")
        mesh = trimesh.util.concatenate(geometries)
    else:
        mesh = loaded

    if not isinstance(mesh, trimesh.Trimesh):
        raise ValueError(f"Unsupported mesh payload from file: {mesh_path}")

    mesh = mesh.copy()
    if mesh.faces is None or len(mesh.faces) == 0:
        raise ValueError(f"Mesh has no faces: {mesh_path}")

    if not mesh.is_watertight:
        # Non-watertight is acceptable for rendering, but we still normalize scale.
        pass

    mesh.apply_translation(-mesh.bounding_box.centroid)
    max_extent = float(np.max(mesh.extents))
    if max_extent > 0.0:
        mesh.apply_scale(1.6 / max_extent)
    
    # Convert to the engine's canonical static layout:
    # pos(3), color(3), normal(3), uv(2)
    positions = mesh.vertices.astype(np.float32)
    normals = mesh.vertex_normals.astype(np.float32)

    if normals.shape[0] != positions.shape[0]:
        normals = np.zeros_like(positions, dtype=np.float32)

    uv = np.zeros((positions.shape[0], 2), dtype=np.float32)
    visual_uv = getattr(getattr(mesh, "visual", None), "uv", None)
    if visual_uv is not None:
        visual_uv = np.asarray(visual_uv, dtype=np.float32)
        if visual_uv.ndim == 2 and visual_uv.shape[1] >= 2:
            count = min(visual_uv.shape[0], uv.shape[0])
            uv[:count] = visual_uv[:count, :2]

    colors = np.tile(np.array(color, dtype=np.float32), (positions.shape[0], 1))
    packed_vertices = np.hstack((positions, colors, normals, uv)).reshape(-1).astype(np.float32)

    # Face indices stay in object-local vertex space.
    index_buffer = mesh.faces.reshape(-1).astype(np.uint32)
    skin_weights = _extract_skin_weights(mesh, positions.shape[0])
    return packed_vertices, index_buffer, skin_weights