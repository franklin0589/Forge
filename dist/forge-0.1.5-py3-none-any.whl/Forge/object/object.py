from pathlib import Path

from .mesh import Mesh
from .materials import Material
from .model import Model
from .rig import Skeleton
from geometry.transform import Transform


# Scene-level entity base with only an id + transform.
class Object:
    def __init__(self, transform: Transform | None = None):
        self.id = id(self)
        self.transform = transform if transform is not None else Transform()

class RenderableObject(Object):
    def __init__(
        self,
        mesh: Mesh,
        transform: Transform | None = None,
        texture_path: str | None = None,
        material: Material | None = None,
    ):
        super().__init__(transform=transform)
        self.mesh = mesh
        self.material = material
        resolved_texture_path = texture_path
        if resolved_texture_path is None and material is not None:
            resolved_texture_path = material.texture_path

        self.texture_path: Path | None = Path(resolved_texture_path) if resolved_texture_path is not None else None


        # Build the render model immediately so Scene can submit it directly.
        self.build()

    def build(self) -> Model:
        # Compose one model payload from mesh + transform + material wiring.
        self.model = Model(
        	vertices=self.mesh.get_vertices(),
			indices=self.mesh.get_indices(),
			texture_path=str(self.texture_path) if self.texture_path is not None else None,
			vertex_format="3f 3f 3f 2f",
			attributes=["in_pos", "in_color", "in_normal", "in_uv"],
			point=self.transform,
			vertex_shader_path=self.material.vertex_shader_path if self.material is not None else None,
			fragment_shader_path=self.material.fragment_shader_path if self.material is not None else None,
			material=self.material,
		)
        return self.model


class SkeletonDebugObject(Object):
    """Renderable line overlay for a Skeleton's current pose."""

    def __init__(
        self,
        skeleton: Skeleton,
        transform: Transform | None = None,
        color: tuple[float, float, float] = (1.0, 0.95, 0.2),
    ):
        super().__init__(transform=transform)
        self.skeleton = skeleton
        self.color = color
        self.material = Material(use_texture=False, use_lighting=False)
        self.mesh = self.skeleton.build_bone_mesh(color=self.color)
        self.build()

    def build(self) -> Model:
        self.model = Model(
            vertices=self.mesh.get_vertices(),
            indices=self.mesh.get_indices(),
            texture_path=None,
            vertex_format="3f 3f",
            attributes=["in_pos", "in_color"],
            point=self.transform,
            material=self.material,
            render_mode="lines",
            depth_test=False,
        )
        return self.model

    def update_from_skeleton(self) -> None:
    
        self.mesh = self.skeleton.build_bone_mesh(color=self.color)
        self.model.vertices = self.mesh.get_vertices()
        self.model.indices = self.mesh.get_indices()
        self.model.point = self.transform.matrix