
import numpy as np
from dataclasses import dataclass, field

def identity():
    return np.eye(4, dtype=np.float32)

@dataclass
class Transform:
    matrix: np.ndarray = field(default_factory=identity)
   
    def __matmul__(self, other: 'Transform') -> 'Transform':
        return Transform(matrix=self.matrix @ other.matrix)

    def inverse(self) -> 'Transform':
        return Transform(matrix=np.linalg.inv(self.matrix))

    def as_type(self, dtype: np.dtype) -> np.ndarray:
        return self.matrix.astype(dtype)

    def copy(self):
        return Transform(matrix=self.matrix.copy())
    
    def translate(self, tx: float, ty: float, tz: float):
        self.matrix = self.matrix @ np.array([
            [1, 0, 0, tx],
            [0, 1, 0, ty],
            [0, 0, 1, tz],
            [0, 0, 0, 1]
        ])
        return self

    def rotate_z(self, angle_deg: float):
        a = np.radians(angle_deg)
        c = np.cos(a)
        s = np.sin(a)
        self.matrix = self.matrix @ np.array([
            [c, -s, 0, 0],
            [s, c, 0, 0],
            [0, 0, 1, 0],
            [0, 0, 0, 1]
        ])
        return self

    def rotate_y(self, angle_deg: float):
        a = np.radians(angle_deg)
        c = np.cos(a)
        s = np.sin(a)
        self.matrix = self.matrix @ np.array([
            [c, 0, s, 0],
            [0, 1, 0, 0],
            [-s, 0, c, 0],
            [0, 0, 0, 1]
        ])
        return self 
    
    def rotate_x(self, angle_deg: float):
        a = np.radians(angle_deg)
        c = np.cos(a)
        s = np.sin(a)
        self.matrix = self.matrix @ np.array([
            [1, 0, 0, 0],
            [0, c, -s, 0],
            [0, s, c, 0],
            [0, 0, 0, 1]
        ])
        return self
    def scale(self, sx: float, sy: float, sz: float):
        self.matrix = self.matrix @ np.array([
            [sx, 0, 0, 0],
            [0, sy, 0, 0],
            [0, 0, sz, 0],
            [0, 0, 0, 1]
        ])
        return self
    
