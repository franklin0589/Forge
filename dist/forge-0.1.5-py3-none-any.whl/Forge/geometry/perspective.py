import numpy as np
from geometry.transform import Transform
from geometry.vector import Vector3


def translation_matrix(tx: float, ty: float, tz: float) -> Transform:
	m = np.eye(4, dtype=np.float32)
	m[0, 3] = tx
	m[1, 3] = ty
	m[2, 3] = tz
	return Transform(m)


def rotation_x_matrix(angle_deg: float) -> Transform:
	a = np.radians(angle_deg)
	c = np.cos(a)
	s = np.sin(a)
	m = np.eye(4, dtype=np.float32)
	m[1, 1] = c
	m[1, 2] = -s
	m[2, 1] = s
	m[2, 2] = c
	return Transform(m)


def rotation_y_matrix(angle_deg: float) -> Transform:
	a = np.radians(angle_deg)
	c = np.cos(a)
	s = np.sin(a)
	m = np.eye(4, dtype=np.float32)
	m[0, 0] = c
	m[0, 2] = s
	m[2, 0] = -s
	m[2, 2] = c
	return Transform(m)


def rotation_z_matrix(angle_deg: float) -> Transform:
	a = np.radians(angle_deg)
	c = np.cos(a)
	s = np.sin(a)
	return Transform(np.array(
		[
			[c, -s, 0.0, 0.0],
			[s, c, 0.0, 0.0],
			[0.0, 0.0, 1.0, 0.0],
			[0.0, 0.0, 0.0, 1.0],
		],
		dtype=np.float32,
	))


def normalize(v: np.ndarray) -> np.ndarray:
	norm = np.linalg.norm(v)
	if norm == 0.0:
		return v
	return v / norm


def look_at(eye: Vector3, target: Vector3, up: Vector3) -> Transform:
	f = normalize(target.as_numpy() - eye.as_numpy())
	s = normalize(np.cross(f, up.as_numpy()))
	u = np.cross(s, f)

	m = np.eye(4, dtype=np.float32)
	m[0, 0:3] = s
	m[1, 0:3] = u
	m[2, 0:3] = -f
	m[0, 3] = -np.dot(s, eye.as_numpy())
	m[1, 3] = -np.dot(u, eye.as_numpy())
	m[2, 3] = np.dot(f, eye.as_numpy())
	return Transform(m)


def perspective(fov_y_deg: float, aspect: float, near: float, far: float) -> Transform:
	f = 1.0 / np.tan(np.radians(fov_y_deg) * 0.5)
	m = np.zeros((4, 4), dtype=np.float32)
	m[0, 0] = f / aspect
	m[1, 1] = f
	m[2, 2] = (far + near) / (near - far)
	m[2, 3] = (2.0 * far * near) / (near - far)
	m[3, 2] = -1.0
	return Transform(m)
