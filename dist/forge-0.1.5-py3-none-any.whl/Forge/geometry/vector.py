from dataclasses import dataclass
import numpy as np

@dataclass
class Vector2:
    x: float
    y: float

    def as_numpy(self) -> np.ndarray:
        return np.array([self.x, self.y], dtype=np.float32)

    @staticmethod
    def from_numpy(array: np.ndarray) -> 'Vector2':
        if array.shape != (2,):
            raise ValueError("Input array must be of shape (2,)")
        return Vector2(x=array[0], y=array[1])

@dataclass
class Vector3:
    x: float
    y: float
    z: float

    def __iter__(self):
        return iter((self.x, self.y, self.z))

    def as_numpy(self) -> np.ndarray:
        return np.array([self.x, self.y, self.z], dtype=np.float32)

    @staticmethod
    def from_numpy(array: np.ndarray) -> 'Vector3':
        if array.shape != (3,):
            raise ValueError("Input array must be of shape (3,)")
        return Vector3(x=array[0], y=array[1], z=array[2])