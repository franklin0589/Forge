
from dataclasses import dataclass
import numpy as np

@dataclass
class Color:
    r: float
    g: float
    b: float
    a: float = 1.0

    def __iter__(self):
        return iter((self.r, self.g, self.b, self.a))

    def as_tuple(self) -> tuple[float, float, float, float]:
        return (self.r, self.g, self.b, self.a)

    def as_numpy(self) -> np.ndarray:
        return np.array([self.r, self.g, self.b, self.a], dtype=np.float32)

BLACK = Color(0.0, 0.0, 0.0, 1.0)
RED = Color(1.0, 0.0, 0.0, 1.0)
ORANGE = Color(1.0, 0.5, 0.0, 1.0)
YELLOW = Color(1.0, 1.0, 0.0, 1.0)
GREEN = Color(0.0, 1.0, 0.0, 1.0)
BLUE = Color(0.0, 0.0, 1.0, 1.0)
PURPLE = Color(0.5, 0.0, 0.5, 1.0)
WHITE = Color(1.0, 1.0, 1.0, 1.0)