from dataclasses import dataclass
import numpy as np
from geometry.transform import Transform

@dataclass
class Quaternion:
    x: float
    y: float
    z: float
    w: float

    def as_numpy(self) -> np.ndarray:
        return np.array([self.x, self.y, self.z, self.w], dtype=np.float32)
    
    def rotate_transform(self, transform: Transform) -> Transform:
        # Convert quaternion to rotation matrix
        q = self.as_numpy()
        x, y, z, w = q
        rotation_matrix = np.array([
            [1 - 2 * (y**2 + z**2), 2 * (x * y - z * w), 2 * (x * z + y * w), 0],
            [2 * (x * y + z * w), 1 - 2 * (x**2 + z**2), 2 * (y * z - x * w), 0],
            [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x**2 + y**2), 0],
            [0, 0, 0, 1]
        ], dtype=np.float32)
        
        # Apply rotation to the transform's matrix
        new_matrix = rotation_matrix @ transform.matrix
        return Transform(matrix=new_matrix)
