import unittest

class TestScene(unittest.TestCase):
    ...